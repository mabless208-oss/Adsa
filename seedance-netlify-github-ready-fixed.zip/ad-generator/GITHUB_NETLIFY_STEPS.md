# Exact GitHub deployment layout

The GitHub repository root must contain:

- `package.json`
- `vite.config.js`
- `index.html`
- `src/`
- `server/`
- `netlify/`
- `netlify.toml`

Do NOT upload the outer folder as an extra nesting level. If the GitHub repository opens directly to `package.json`, the Netlify Base directory should be empty.

Netlify settings:
- Branch: `main`
- Base directory: empty
- Build command: `npm run build`
- Publish directory: `dist`
- Functions directory: `netlify/functions`

Environment variables:
- `KIE_API_KEY` = your rotated Kie.ai API key
- `KIE_API_URL` = `https://api.kie.ai`

After deployment, test `https://YOUR-SITE.netlify.app/api/health` and expect `{"status":"ok","platform":"netlify"}`.
